#ifndef JUSTTEST_H
#define JUSTTEST_H
#include "generalfunctions.h"
class JustTest
{
public:
    JustTest();
};

#endif // JUSTTEST_H
